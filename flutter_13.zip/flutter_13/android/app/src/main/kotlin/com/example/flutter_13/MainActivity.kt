package com.example.flutter_13

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
