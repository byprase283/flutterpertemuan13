import 'package:flutter/material.dart';
import '../services/notification_helper.dart';
import '../widgets/custom_button.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Notification Demo')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomButton(
              text: 'Show Notification with Payload',
              onPressed: () async {
                await NotificationHelper().showNotification(
                  id: 1,
                  title: 'Hello!',
                  body: 'This notification has a payload',
                  payload: '1',
                );
              },
            ),
            const SizedBox(height: 16),

            // CustomButton(
            //   text: 'Schedule Notification in 5 seconds',
            //   onPressed: () async {
            //     await NotificationHelper().scheduleNotification(
            //       id: 2,
            //       title: 'Scheduled Notification',
            //       body: 'This was scheduled 5 seconds ago',
            //       payload: 'scheduled_payload',
            //       seconds: 5,
            //     );
            //   },
            // ),
            // const SizedBox(height: 16),
            // CustomButton(
            //   text: 'Schedule Notification in 5 seconds',
            //   onPressed: () async {
            //     await NotificationHelper().scheduleNotification(
            //       id: 2,
            //       title: 'Scheduled Notification',
            //       body: 'This was scheduled 5 seconds ago',
            //       payload: 'scheduled_payload',
            //       seconds: 5,
            //     );
            //   },
            // ),
            const SizedBox(height: 16),
            CustomButton(
              text: 'Show Notification No Body with Payload',
              onPressed: () async {
                await NotificationHelper().showNotification(
                  id: 3,
                  title: 'No Body Notification',
                  body: '', // kosongkan body
                  payload: '1',
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
