import 'package:flutter/material.dart';
import 'package:flutter_13v2/pages/detail_page.dart';
import 'pages/home_page.dart';
import 'services/notification_helper.dart';
import 'package:permission_handler/permission_handler.dart';

Future<void> requestNotificationPermission() async {
  if (await Permission.notification.isDenied) {
    await Permission.notification.request();
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await requestNotificationPermission();
  await NotificationHelper().initNotifications(
    onSelectNotification: (payload) {
      print('Notification payload: $payload');
      if (payload != null) {
        int? postId = int.tryParse(payload);
        if (postId != null) {
          navigatorKey.currentState?.push(
            MaterialPageRoute(builder: (_) => DetailPage(postId: 1)),
          );
        }
      }
    },
  );

  runApp(const MyApp());
}

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey,
      title: 'Flutter Notification Demo',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const HomePage(),
    );
  }
}
