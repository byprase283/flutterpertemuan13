package com.example.flutter_13v2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
